#ifndef ICONS_8X8_H
#define ICONS_8X8_H

#include <Arduino.h>

// =================================================================
// Enhanced 8x8 Monochrome Icons for Low-Resolution Displays
// =================================================================

// 📍 Location Pin Icon (Clearer point and circle)
const unsigned char locationIcon [] PROGMEM = {
  0b00111100, // Top of pin (wide base)
  0b01111110,
  0b01100110, // Circle body (center hole)
  0b01111110,
  0b00111100, // Neck
  0b00011000, // Point
  0b00000000,
  0b00000000
};

// ☁️ Cloud Icon (Smoother, fluffier shape)
const unsigned char cloudIcon [] PROGMEM = {
  0b00000000,
  0b00111100,
  0b01111110,
  0b11111111, // Full row for weight
  0b11111110,
  0b01111100,
  0b00000000,
  0b00000000
};

// 💧 Droplet/Rain Icon (Thinner, more distinct drop shape)
const unsigned char dropletIcon [] PROGMEM = {
  0b00001000,
  0b00011100,
  0b00111110,
  0b01111110, // Widest point
  0b00111110,
  0b00011100,
  0b00001000,
  0b00000000
};

// ☀️ Sun Icon (Clear center circle with distinct, thinner rays)
const unsigned char sunIcon [] PROGMEM = {
  0b10011001, // Diagonal rays
  0b00111100,
  0b01000010, // Center ring
  0b10000001, // Horizontal/Vertical rays
  0b01000010, // Center ring
  0b00111100,
  0b10011001, // Diagonal rays
  0b00000000
};

// 🌙 Moon Icon (Crescent shape)
const unsigned char moonIcon [] PROGMEM = {
  0b00111100,
  0b01111000,
  0b11110000,
  0b11100000,
  0b11110000,
  0b01111000,
  0b00111100,
  0b00000000
};

// 🌤️ Partly Cloudy Icon (Sun peeking over the cloud)
const unsigned char partlyCloudyIcon [] PROGMEM = {
  0b11110000, // Sun top left corner
  0b11111000,
  0b11111100,
  0b01111110,
  0b11111111, // Cloud body covers bottom of sun
  0b11111110,
  0b00000000,
  0b00000000
};

// 🌬️ Air Quality/Wind Icon (Simplified, clearer S-shape for flow)
const unsigned char airIcon [] PROGMEM = {
  0b00000110, // Swirl top right
  0b00011000,
  0b01100000,
  0b10000000,
  0b00000010, // <-- CORRECTED: Ensured byte is 8 bits and shape is clean
  0b00001100,
  0b00011100,
  0b00110000 // Swirl bottom left
};

// 🌡️ Thermometer Icon (Clear bulb and stem with liquid indicator)
const unsigned char thermometerIcon [] PROGMEM = {
  0b00111100, // Top of glass
  0b01000010, // Stem
  0b01000010,
  0b01000010,
  0b01011010, // Liquid fill (half-full)
  0b01011010,
  0b00111100, // Neck
  0b01111110  // Bulb
};

// 📅 Calendar Icon (Clear header, simplified body)
const unsigned char calendarIcon [] PROGMEM = {
  0b11111111, // Header (Month)
  0b11000011, // Weekday markers
  0b11111111, // Divider
  0b10101011, // Date 1
  0b10101011, // Date 2
  0b10101011, // Date 3
  0b11111111, // Footer
  0b00000000
};

// =================================================================
// 🌧️ Rain Icons (8x8 Monochrome Bitmaps)
// =================================================================

// 🌧️ Rain Icon (Fluffy cloud with diagonal falling raindrops)
const unsigned char rainIcon [] PROGMEM = {
  0b00110000, // Cloud puff top
  0b01111100, // Cloud upper body
  0b11111110, // Cloud base
  0b00000000, // Gap between cloud and rain
  0b01010100, // Rain drops row 1 (3 raindrops)
  0b00101010, // Slanted rain drops row 2
  0b01010100, // Rain drops row 3
  0b00000000
};

// ⛈️ Heavy Rain / Downpour Icon (Dense storm rainfall)
const unsigned char heavyRainIcon [] PROGMEM = {
  0b00111100, // Cloud top
  0b01111110, // Cloud body
  0b11111111, // Cloud base
  0b00000000, // Gap
  0b10101010, // Heavy rain columns
  0b01010101, // Downpour slant
  0b10101010, // Ground impact
  0b00000000
};

// 🌩️ Thunderstorm / Thunder Rain Icon (Cloud with lightning bolt and rain)
const unsigned char thunderRainIcon [] PROGMEM = {
  0b00111000, // Cloud top
  0b01111110, // Cloud body
  0b11111111, // Cloud base
  0b00110000, // Lightning top
  0b01100100, // Lightning zig + rain drop
  0b00110010, // Lightning zag + rain drop
  0b00010100, // Lightning tip + rain drop
  0b00000000
};

// ☂️ Umbrella Icon (Opened umbrella protection against rain)
const unsigned char umbrellaIcon [] PROGMEM = {
  0b00010000, // Umbrella tip
  0b00111000, // Canopy top
  0b01111100, // Canopy body
  0b11111110, // Canopy rim
  0b00010000, // Shaft
  0b00010000, // Shaft
  0b00010010, // Handle bend
  0b00001100  // Curved J-hook handle
};

// =================================================================
// ☀️ UV (Ultraviolet) Icons (8x8 Monochrome Bitmaps)
// =================================================================

// ☀️ UV Text Monogram Icon (Crisp 'U' & 'V' index label)
const unsigned char uvIcon [] PROGMEM = {
  0b00000000,
  0b10101001, // 'U' arms and 'V' outer wings
  0b10101001, // 'U' body and 'V' outer wings
  0b10101001, // 'U' body and 'V' outer wings
  0b10100110, // 'U' body and 'V' inner vertex
  0b01000110, // 'U' rounded base and 'V' tip
  0b00000000,
  0b00000000
};

// 🧴 UV Sun & Radiation Icon (Sun emitting downward high-intensity rays)
const unsigned char uvSunIcon [] PROGMEM = {
  0b00111100, // Sun top
  0b01111110, // Sun core
  0b00111100, // Sun bottom
  0b00000000, // Gap
  0b10100101, // Penetrating UV rays
  0b01011010, // Radiating waves
  0b00000000, // Atmosphere gap
  0b11111111  // Surface exposure line
};

// 🔆 UV Index / Solar Radiation Badge (Sun disk with high-energy rays)
const unsigned char uvIndexIcon [] PROGMEM = {
  0b01011010, // Divergent UV rays
  0b10011001,
  0b00111100, // Concentrated solar core
  0b11111111, // Peak radiation ring
  0b11111111,
  0b00111100, // Core bottom
  0b10011001,
  0b01011010  // Divergent UV rays
};

// 🕶️ Sunglasses / UV Protection Icon (Classic shades for high UV index)
const unsigned char sunglassesIcon [] PROGMEM = {
  0b00000000,
  0b11111111, // Top brow bar
  0b11100111, // Left and right lens frames
  0b11100111, // Lens dark fill
  0b11100111, // Lens dark fill
  0b01100110, // Rounded lower lens rims
  0b00000000,
  0b00000000
};

// =================================================================
// 💨 Wind Speed & Direction Icons (8x8 Monochrome Bitmaps)
// =================================================================

// 💨 Wind Speed / Wind Gusts Icon (Horizontal blowing wind streams with curls)
const unsigned char windSpeedIcon [] PROGMEM = {
  0b00001100, // Top stream loop curl top
  0b11110010, // Top stream body entering loop
  0b00001100, // Top stream loop curl base
  0b00000000, // Airflow channel gap
  0b11111110, // Main middle gust (high-speed straight stream)
  0b00000000, // Airflow channel gap
  0b00111110, // Lower breeze stream
  0b00000010  // Lower breeze curl tip
};

// 💨 Alias for general wind icon usage
const unsigned char windIcon [] PROGMEM = {
  0b00001100,
  0b11110010,
  0b00001100,
  0b00000000,
  0b11111110,
  0b00000000,
  0b00111110,
  0b00000010
};

// 🚩 Windsock Icon (Meteorological airport wind cone indicating speed & heading)
const unsigned char windsockIcon [] PROGMEM = {
  0b11000000, // Mast pivot collar
  0b11111100, // Wide cone mouth
  0b10111110, // First stripe segment
  0b10011110, // Middle stripe segment
  0b10001110, // Trailing cone tail in wind
  0b10000000, // Mast pole
  0b10000000, // Mast pole
  0b11100000  // Base mount
};

// ⏱️ Anemometer Icon (3-cup rotational wind speed measurement gauge)
const unsigned char anemometerIcon [] PROGMEM = {
  0b01100110, // Left cup and right cup
  0b11111111, // Horizontal rotating crossbar
  0b00011000, // Central rotor spindle
  0b00011000, // Vertical support shaft
  0b00011000, // Vertical support shaft
  0b00011000, // Vertical support shaft
  0b00111100, // Mounting collar
  0b01111110  // Ground / bracket mount
};

// 🧭 Wind Direction / Compass Icon (Nautical compass rose with North pointer)
const unsigned char windDirectionIcon [] PROGMEM = {
  0b00011000, // North needle tip
  0b00111100, // North needle body
  0b01111110, // North needle wide base (solid)
  0b11100111, // Center pivot and West-East ticks
  0b01100110, // South needle outline base (hollow)
  0b00100100, // South needle outline stem
  0b00011000, // South needle tip
  0b00000000
};

// 🧭 Alias for compass icon usage
const unsigned char compassIcon [] PROGMEM = {
  0b00011000,
  0b00111100,
  0b01111110,
  0b11100111,
  0b01100110,
  0b00100100,
  0b00011000,
  0b00000000
};

// 🐓 Wind Vane / Weathercock Icon (Directional arrow on rooftop spindle)
const unsigned char windVaneIcon [] PROGMEM = {
  0b00010000, // Arrow pointer tip
  0b00111000, // Arrow head
  0b11111111, // Arrow shaft with tail fin
  0b00010000, // Pivot bearing
  0b01010100, // Cardinal direction crossbar (W - E)
  0b00010000, // Spindle
  0b00010000, // Spindle
  0b00111100  // Rooftop mount
};

// =================================================================
// 🧭 Cardinal Wind Direction Arrows (8x8 Bitmaps for Weather API)
// =================================================================

// ⬆️ Wind Arrow North (N - 0° / 360°)
const unsigned char windArrowN [] PROGMEM = {
  0b00011000, // Tip
  0b00111100, // Head
  0b01111110, // Barbs
  0b11011011, // Wings
  0b00011000, // Stem
  0b00011000, // Stem
  0b00011000, // Stem
  0b00000000
};

// ↗️ Wind Arrow North-East (NE - 45°)
const unsigned char windArrowNE [] PROGMEM = {
  0b00011111, // Top-right tip and barb
  0b00001111, // Head
  0b00011111, // Head and stem junction
  0b00110011, // Diagonal stem and barb
  0b01100001, // Diagonal stem
  0b11000000, // Shaft base
  0b10000000, // Tail
  0b00000000
};

// ➡️ Wind Arrow East (E - 90°)
const unsigned char windArrowE [] PROGMEM = {
  0b00001000, // Upper barb
  0b00001100, // Upper head
  0b00001110, // Upper tip
  0b11111111, // Center horizontal shaft & tip
  0b11111111, // Center horizontal shaft & tip
  0b00001110, // Lower tip
  0b00001100, // Lower head
  0b00001000  // Lower barb
};

// ↘️ Wind Arrow South-East (SE - 135°)
const unsigned char windArrowSE [] PROGMEM = {
  0b10000000, // Tail
  0b11000000, // Shaft base
  0b01100001, // Diagonal stem
  0b00110011, // Diagonal stem and barb
  0b00011111, // Head and stem junction
  0b00001111, // Head
  0b00011111, // Bottom-right tip and barb
  0b00000000
};

// ⬇️ Wind Arrow South (S - 180°)
const unsigned char windArrowS [] PROGMEM = {
  0b00011000, // Stem
  0b00011000, // Stem
  0b00011000, // Stem
  0b11011011, // Wings
  0b01111110, // Barbs
  0b00111100, // Head
  0b00011000, // Tip
  0b00000000
};

// ↙️ Wind Arrow South-West (SW - 225°)
const unsigned char windArrowSW [] PROGMEM = {
  0b00000001, // Tail
  0b00000011, // Shaft base
  0b10000110, // Diagonal stem
  0b11001100, // Diagonal stem and barb
  0b11111000, // Head and stem junction
  0b11110000, // Head
  0b11111000, // Bottom-left tip and barb
  0b00000000
};

// ⬅️ Wind Arrow West (W - 270°)
const unsigned char windArrowW [] PROGMEM = {
  0b00010000, // Upper barb
  0b00110000, // Upper head
  0b01110000, // Upper tip
  0b11111111, // Center horizontal shaft & tip
  0b11111111, // Center horizontal shaft & tip
  0b01110000, // Lower tip
  0b00110000, // Lower head
  0b00010000  // Lower barb
};

// ↖️ Wind Arrow North-West (NW - 315°)
const unsigned char windArrowNW [] PROGMEM = {
  0b11111000, // Top-left tip and barb
  0b11110000, // Head
  0b11111000, // Head and stem junction
  0b11001100, // Diagonal stem and barb
  0b10000110, // Diagonal stem
  0b00000011, // Shaft base
  0b00000001, // Tail
  0b00000000
};

// Helper function to return the matching 8x8 wind direction arrow from an API string
inline const unsigned char* getWindArrowIcon(const String &dir) {
  if (dir.equalsIgnoreCase("N")) return windArrowN;
  if (dir.equalsIgnoreCase("NNE") || dir.equalsIgnoreCase("NE") || dir.equalsIgnoreCase("ENE")) return windArrowNE;
  if (dir.equalsIgnoreCase("E")) return windArrowE;
  if (dir.equalsIgnoreCase("ESE") || dir.equalsIgnoreCase("SE") || dir.equalsIgnoreCase("SSE")) return windArrowSE;
  if (dir.equalsIgnoreCase("S")) return windArrowS;
  if (dir.equalsIgnoreCase("SSW") || dir.equalsIgnoreCase("SW") || dir.equalsIgnoreCase("WSW")) return windArrowSW;
  if (dir.equalsIgnoreCase("W")) return windArrowW;
  if (dir.equalsIgnoreCase("WNW") || dir.equalsIgnoreCase("NW") || dir.equalsIgnoreCase("NNW")) return windArrowNW;
  return windDirectionIcon; // Default fallback to compass
}

// Helper overload to return the matching 8x8 wind arrow from degrees (0 - 360°)
inline const unsigned char* getWindArrowIcon(int deg) {
  deg = (deg % 360 + 360) % 360;
  if (deg >= 338 || deg < 23)   return windArrowN;
  if (deg >= 23  && deg < 68)   return windArrowNE;
  if (deg >= 68  && deg < 113)  return windArrowE;
  if (deg >= 113 && deg < 158)  return windArrowSE;
  if (deg >= 158 && deg < 203)  return windArrowS;
  if (deg >= 203 && deg < 248)  return windArrowSW;
  if (deg >= 248 && deg < 293)  return windArrowW;
  return windArrowNW;
}

// =================================================================
// 🌅 Celestial Rise & Set Icons (8x8 Monochrome Bitmaps)
// =================================================================

// 🌅 Sunrise Icon (Sun rising above horizon with upward indicator)
const unsigned char sunriseIcon [] PROGMEM = {
  0b00011000, // Up arrow tip
  0b00111100, // Up arrow head
  0b00011000, // Up arrow stem
  0b01000010, // Sun rays
  0b00111100, // Sun dome
  0b01111110, // Sun disc
  0b11111111, // Horizon line
  0b00000000
};

// 🌇 Sunset Icon (Sun setting below horizon with downward indicator)
const unsigned char sunsetIcon [] PROGMEM = {
  0b01000010, // Sun rays
  0b00111100, // Sun dome
  0b01111110, // Sun disc
  0b11111111, // Horizon line
  0b00011000, // Down arrow stem
  0b00111100, // Down arrow head
  0b00011000, // Down arrow tip
  0b00000000
};

// 🌙⬆️ Moonrise Icon (Crescent moon with upward indicator)
const unsigned char moonriseIcon [] PROGMEM = {
  0b01100010, // Moon top + up arrow tip
  0b11100111, // Moon + arrow head
  0b11000010, // Moon + arrow stem
  0b11000010, // Moon center + arrow stem
  0b11000000, // Moon center
  0b11100000, // Moon lower curve
  0b01100000, // Moon bottom
  0b00000000
};

// 🌙⬇️ Moonset Icon (Crescent moon with downward indicator)
const unsigned char moonsetIcon [] PROGMEM = {
  0b01100000, // Moon top
  0b11100000, // Moon upper curve
  0b11000000, // Moon center
  0b11000010, // Moon center + down arrow stem
  0b11000010, // Moon center + down arrow stem
  0b11100111, // Moon lower + arrow head
  0b01100010, // Moon bottom + down arrow tip
  0b00000000
};

#endif
