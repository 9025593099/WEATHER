// ESP32 Board link "https://raw.githubusercontent.com/espressif/arduino-esp32/gh-pages/package_esp32_index.json"
#include <WiFi.h>
#include <HTTPClient.h>
#include <WiFiClientSecure.h>
#include <ArduinoJson.h>
#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>
#include "time.h"
#include "Imojies.h" // Ensure this file defines moonIcon, sunIcon, cloudIcon, etc.

// --- Wi-Fi & API ---
const char* ssid = "ENTER WIFI NAME";
const char* password = "ENTER WIFI PASSWORD";

// Latitude and Longitude (Mukuperi: lat=8.5705091, lon=77.9878221)
String latitude = "8.5705091";
String longitude = "77.9878221";

// Windy.com Point Forecast API (Get your free key from https://api.windy.com/)
String Authentication_Key = "API KEY"; // Put your Windy.com API Key here
const char* windyEndpoint = "https://api.windy.com/api/point-forecast/v2";
const char* windyModel = "gfs";

// --- Time ---
const char* ntpServer = "pool.ntp.org";
const long gmtOffset_sec = 19800;
const int daylightOffset_sec = 0;

// --- Display ---
#define SCREEN_WIDTH 128
#define SCREEN_HEIGHT 64
#define OLED_RESET -1
#define SCREEN_ADDRESS 0x3C
Adafruit_SSD1306 display(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire, OLED_RESET);

// --- Weather Data ---
String weatherCondition = "";
int humidity = 0;
int airQuality = 0;
float temperature = 0.0;
float windSpeed = 0.0;
String windDirection = "";
int windDirDegrees = 0;
String location = "Mukuperi";

// --- Forecast Data ---
String forecastDay[3];
String forecastCondition[3];
float forecastTemp[3];
int forecastHumidity[3];

// --- Sun & Moon Data ---
String sunriseTime = "--:--";
String sunsetTime = "--:--";
String moonriseTime = "--:--";
String moonsetTime = "--:--";

// --- UI State ---
int infoState = 0;
unsigned long lastInfoChange = 0;
const int infoInterval = 4000;
unsigned long lastWeatherUpdate = 0;
const unsigned long weatherUpdateInterval = 5 * 60 * 1000UL; // Fetch weather every 5 minutes (300,000 ms)

// --- Connection State ---
bool wasConnected = false;

// --- Functions (Prototypes) ---
void drawCenteredString(const String &text, int y);
void connectWiFi();
void handleWiFiDisconnection();
void displayInfo();
void initTime();
void fetchWindyData();
void calculateSunTimes();
void getWeatherData();
void getForecastData();
String formatTimestamp(time_t ts);

// --- Setup ---
void setup() {
  Serial.begin(115200);
  Wire.begin(21, 22); // Explicitly define I2C pins for ESP32

  // Initialize SSD1306 OLED
  if (!display.begin(SSD1306_SWITCHCAPVCC, SCREEN_ADDRESS)) {
    Serial.println(F("SSD1306 allocation failed"));
    for (;;);
  }

  display.clearDisplay();
  display.setTextSize(1);
  display.setTextColor(SSD1306_WHITE);

  connectWiFi();

  if (WiFi.status() == WL_CONNECTED) {
    wasConnected = true;
  }

  initTime();
  getWeatherData();
  getForecastData();

  // ✅ Prevent skipping case 0
  lastInfoChange = millis();

  // ✅ Show case 0 immediately at startup
  displayInfo();
}

// --- Loop ---
void loop() {
  if (WiFi.status() == WL_CONNECTED) {
    if (!wasConnected) {
      wasConnected = true;
      Serial.println("Reconnected to WiFi.");
      initTime();
      getWeatherData();
      getForecastData();
      lastWeatherUpdate = millis();

      display.clearDisplay();
      drawCenteredString("Reconnected!", SCREEN_HEIGHT / 2 - 5);
      display.display();
      delay(1500);
    }

    unsigned long currentTime = millis();

    if (currentTime - lastWeatherUpdate > weatherUpdateInterval) {
      getWeatherData();
      getForecastData();
      lastWeatherUpdate = currentTime;
    }

    if (currentTime - lastInfoChange > infoInterval) {
      infoState = (infoState + 1) % 16;
      lastInfoChange = currentTime;
    }

    displayInfo();
  } else {
    if (wasConnected) {
      Serial.println("WiFi connection lost. Attempting to reconnect...");
      wasConnected = false;
    }
    handleWiFiDisconnection(); 
  }
}

// --- Functions ---
void handleWiFiDisconnection() {
  // Static variables to persist state across function calls
  static int x_pos = -20; // Animation position
  static unsigned long lastReconnectAttempt = 0;
  const int reconnectInterval = 10000; // Try to reconnect every 10 seconds

  unsigned long currentTime = millis();

  // Periodically attempt to reconnect in a non-blocking way
  if (currentTime - lastReconnectAttempt > reconnectInterval) {
    Serial.println("Attempting WiFi reconnection...");
    WiFi.begin(ssid, password); // This is non-blocking
    lastReconnectAttempt = currentTime;
  }

  // --- Draw the Disconnected UI ---
  display.clearDisplay();

  // 1. Draw Time and Date (still works from internal clock)
  struct tm timeinfo;
  if (!getLocalTime(&timeinfo)) {
    display.setTextSize(2);
    drawCenteredString("??:?? ??", 5);
    display.setTextSize(1);
    drawCenteredString("No Time Sync", 25);
  } else {
    char timeHour[3], timeMinute[3], timeAmPm[3], dateString[20];
    strftime(timeHour, sizeof(timeHour), "%I", &timeinfo);
    strftime(timeMinute, sizeof(timeMinute), "%M", &timeinfo);
    strftime(timeAmPm, sizeof(timeAmPm), "%p", &timeinfo);
    strftime(dateString, sizeof(dateString), "%a, %b %d", &timeinfo);

    String timeStr = String(timeHour) + ((timeinfo.tm_sec % 2 == 0) ? ":" : " ") + String(timeMinute) + " " + String(timeAmPm);
    display.setTextSize(2);
    drawCenteredString(timeStr, 5);

    display.setTextSize(1);
    int16_t x1, y1;
    uint16_t w, h;
    display.getTextBounds(dateString, 0, 0, &x1, &y1, &w, &h);
    int x = (SCREEN_WIDTH - w) / 2;
    int y = 25;
    display.drawRect(x - 2, y - 2, w + 4, h + 4, SSD1306_WHITE);
    display.setCursor(x, y);
    display.println(dateString);
  }

  // 2. Draw Disconnected Message
  display.setTextSize(1);
  drawCenteredString("WiFi Disconnected", 45);

  // 3. Draw Reconnecting Animation (marquee line at the bottom)
  const int LINE_WIDTH = 30;
  const int LINE_HEIGHT = 2;
  const int Y_POS = SCREEN_HEIGHT - LINE_HEIGHT - 2; // Position at the very bottom
  const int ANIMATION_SPEED = 4;

  display.fillRect(0, Y_POS, SCREEN_WIDTH, LINE_HEIGHT, SSD1306_BLACK); // Clear animation area

  int draw_start_x = max(0, x_pos);
  int draw_width = LINE_WIDTH;
  if (x_pos < 0) { draw_width = LINE_WIDTH + x_pos; }
  if (x_pos + LINE_WIDTH > SCREEN_WIDTH) { draw_width = SCREEN_WIDTH - x_pos; }
  if (draw_width > 0) { display.drawFastHLine(draw_start_x, Y_POS, draw_width, SSD1306_WHITE); }
  
  x_pos += ANIMATION_SPEED;
  if (x_pos > SCREEN_WIDTH) { x_pos = -LINE_WIDTH; } // Reset animation

  display.display();
  delay(50); // Delay for animation smoothness
}


void connectWiFi() {
  Serial.print("Connecting to ");
  Serial.println(ssid);
  
  display.clearDisplay();
  display.setTextSize(1);
  drawCenteredString("Connecting", SCREEN_HEIGHT / 2 - 10);
  
  WiFi.begin(ssid, password);
  
  const int LINE_WIDTH = 20;
  const int LINE_HEIGHT = 2;
  const int Y_POS = SCREEN_HEIGHT / 2 + 5;
  const int ANIMATION_SPEED = 3; 
  int x_pos = 0;
  
  while (WiFi.status() != WL_CONNECTED) {
    display.fillRect(0, Y_POS, SCREEN_WIDTH, LINE_HEIGHT, SSD1306_BLACK); 

    int draw_start_x = max(0, x_pos); 
    int draw_width = LINE_WIDTH; 
    
    if (x_pos < 0) {
        draw_width = LINE_WIDTH + x_pos;
    }
    if (x_pos + LINE_WIDTH > SCREEN_WIDTH) {
        draw_width = SCREEN_WIDTH - x_pos;
    }

    if (draw_width > 0) {
        display.drawFastHLine(draw_start_x, Y_POS, draw_width, SSD1306_WHITE);
    }
    
    x_pos += ANIMATION_SPEED;
    
    if (x_pos > SCREEN_WIDTH) {
      x_pos = -LINE_WIDTH; 
    }
    
    display.display();
    Serial.print(".");
    delay(50); 
  }
  
  display.clearDisplay();
  display.setTextSize(1);
  drawCenteredString("WiFi connected!", SCREEN_HEIGHT / 2 - 5);
  display.display();
  delay(1000); 

  Serial.println("\nWiFi connected.");
}

void initTime() {
  configTime(gmtOffset_sec, daylightOffset_sec, ntpServer);
  Serial.println("Time synchronized.");
}

void fetchWindyData() {
  if (WiFi.status() != WL_CONNECTED) return;

  WiFiClientSecure client;
  client.setInsecure(); // Skip SSL certificate verification on ESP32

  HTTPClient http;
  http.begin(client, windyEndpoint);
  http.addHeader("Content-Type", "application/json");

  // Construct JSON request body for Windy Point Forecast API v2
  String payload = "{\"lat\":" + latitude + 
                   ",\"lon\":" + longitude + 
                   ",\"model\":\"" + String(windyModel) + 
                   "\",\"parameters\":[\"temp\",\"precip\",\"rh\",\"wind\"],\"levels\":[\"surface\"],\"key\":\"" + 
                   Authentication_Key + "\"}";

  Serial.println(F("Fetching weather from Windy.com..."));
  int httpResponseCode = http.POST(payload);

  Serial.print(F("Windy HTTP Code: "));
  Serial.println(httpResponseCode);

  if (httpResponseCode == HTTP_CODE_OK) {
    String response = http.getString();
    DynamicJsonDocument doc(16384);
    DeserializationError error = deserializeJson(doc, response);

    if (error) {
      Serial.print(F("Windy JSON parse error: "));
      Serial.println(error.c_str());
      http.end();
      return;
    }

    // Extract arrays from Windy Point Forecast response
    JsonArray tsArr = doc["ts"].as<JsonArray>();
    JsonArray tempArr = doc["temp-surface"].as<JsonArray>();
    JsonArray rhArr = doc["rh-surface"].as<JsonArray>();
    JsonArray windUArr = doc["wind_u-surface"].as<JsonArray>();
    JsonArray windVArr = doc["wind_v-surface"].as<JsonArray>();

    // Check possible precipitation field names
    JsonArray precipArr;
    if (!doc["past3hprecip-surface"].isNull()) {
      precipArr = doc["past3hprecip-surface"].as<JsonArray>();
    } else if (!doc["precip-surface"].isNull()) {
      precipArr = doc["precip-surface"].as<JsonArray>();
    } else if (!doc["past1hprecip-surface"].isNull()) {
      precipArr = doc["past1hprecip-surface"].as<JsonArray>();
    }

    size_t tsCount = tsArr.size();
    if (tsCount > 0 && tempArr.size() > 0) {
      // 1. Current Weather (timestep 0)
      float rawTemp = tempArr[0].as<float>();
      temperature = (rawTemp > 100.0f) ? (rawTemp - 273.15f) : rawTemp; // Convert Kelvin to Celsius if needed
      humidity = (rhArr.size() > 0) ? rhArr[0].as<int>() : 0;

      // Wind speed and direction
      if (windUArr.size() > 0 && windVArr.size() > 0) {
        float u = windUArr[0].as<float>();
        float v = windVArr[0].as<float>();
        float speed_ms = sqrt(u * u + v * v);
        windSpeed = speed_ms * 3.6f; // Convert m/s to km/h

        // Meteorological wind direction (direction wind blows FROM)
        float rad = atan2(-u, -v);
        float deg = rad * 180.0f / PI;
        if (deg < 0) deg += 360.0f;
        windDirDegrees = (int)(deg + 0.5f) % 360;

        const char* cardinals[] = {"N", "NNE", "NE", "ENE", "E", "ESE", "SE", "SSE",
                                   "S", "SSW", "SW", "WSW", "W", "WNW", "NW", "NNW"};
        int cIdx = (int)((windDirDegrees + 11.25f) / 22.5f) % 16;
        windDirection = cardinals[cIdx];
      }

      // Weather condition based on precipitation and humidity
      float currentPrecip = (precipArr.size() > 0) ? precipArr[0].as<float>() : 0.0f;
      if (currentPrecip > 2.0f) {
        weatherCondition = "Heavy Rain";
      } else if (currentPrecip > 0.3f) {
        weatherCondition = "Rain";
      } else if (currentPrecip > 0.0f) {
        weatherCondition = "Light Rain";
      } else if (humidity >= 80) {
        weatherCondition = "Cloudy";
      } else if (humidity >= 60) {
        weatherCondition = "Partly Cloudy";
      } else {
        weatherCondition = "Clear Sky";
      }

      location = "Mukuperi";
      airQuality = 0; // Windy GFS weather forecast does not include AQI

      Serial.print(F("Weather: "));
      Serial.print(weatherCondition);
      Serial.print(F(", Temp: "));
      Serial.print(temperature);
      Serial.print(F(", Wind: "));
      Serial.print(windSpeed, 1);
      Serial.print(F(" kmph "));
      Serial.print(windDirection);
      Serial.printf(" (%d deg)\n", windDirDegrees);

      // 2. Multi-day Forecast (Today = 0, Tomorrow = 1, Day After = 2)
      for (int i = 0; i < 3; i++) {
        forecastDay[i] = "";
        forecastCondition[i] = "Clear";
        forecastTemp[i] = temperature;
        forecastHumidity[i] = humidity;
      }

      uint64_t t0_ms = tsArr[0].as<uint64_t>();
      time_t t0_sec = (time_t)(t0_ms / 1000ULL) + gmtOffset_sec;
      uint64_t today_midnight = (t0_sec / 86400ULL) * 86400ULL;

      for (size_t k = 0; k < tsCount; k++) {
        uint64_t tk_ms = tsArr[k].as<uint64_t>();
        time_t tk_sec = (time_t)(tk_ms / 1000ULL) + gmtOffset_sec;
        int dayIdx = (int)((tk_sec - today_midnight) / 86400ULL);

        if (dayIdx >= 0 && dayIdx < 3) {
          struct tm *ti = gmtime(&tk_sec);
          if (ti) {
            char dateBuf[16];
            snprintf(dateBuf, sizeof(dateBuf), "%04d-%02d-%02d", ti->tm_year + 1900, ti->tm_mon + 1, ti->tm_mday);

            float rawT = (k < tempArr.size()) ? tempArr[k].as<float>() : 0.0f;
            float tC = (rawT > 100.0f) ? (rawT - 273.15f) : rawT;
            int rh = (k < rhArr.size()) ? rhArr[k].as<int>() : 0;
            float p = (k < precipArr.size()) ? precipArr[k].as<float>() : 0.0f;

            // Pick midday forecast (11:00 - 15:00) or first seen timestamp for the day
            bool isMidday = (ti->tm_hour >= 11 && ti->tm_hour <= 15);
            bool isFirstSeen = (forecastDay[dayIdx].length() == 0);

            if (isFirstSeen || isMidday) {
              forecastDay[dayIdx] = String(dateBuf);
              forecastTemp[dayIdx] = tC;
              forecastHumidity[dayIdx] = rh;

              if (p > 2.0f) forecastCondition[dayIdx] = "Heavy Rain";
              else if (p > 0.3f) forecastCondition[dayIdx] = "Rain";
              else if (p > 0.0f) forecastCondition[dayIdx] = "Light Rain";
              else if (rh >= 80) forecastCondition[dayIdx] = "Cloudy";
              else if (rh >= 60) forecastCondition[dayIdx] = "Partly Cloudy";
              else forecastCondition[dayIdx] = "Clear";
            }
          }
        }
      }

      Serial.print(F("Tomorrow: ")); Serial.print(forecastDay[1]);
      Serial.print(F(", Temp: ")); Serial.print(forecastTemp[1]);
      Serial.print(F(" C, Cond: ")); Serial.println(forecastCondition[1]);
    }
  } else {
    Serial.print(F("Failed to fetch Windy weather. Code: "));
    Serial.println(httpResponseCode);
    if (httpResponseCode > 0) {
      Serial.println(http.getString());
    }
  }
  http.end();

  // Calculate local astronomical sunrise and sunset times
  calculateSunTimes();
}

void getWeatherData() {
  fetchWindyData();
}

void getForecastData() {
  // Windy Point Forecast retrieves current weather and multi-day forecast in one call
}

void calculateSunTimes() {
  struct tm timeinfo;
  if (!getLocalTime(&timeinfo)) {
    return;
  }

  float lat = latitude.toFloat();
  float lon = longitude.toFloat();
  int dayOfYear = timeinfo.tm_yday + 1; // 1 to 366

  // Fractional year in radians
  float gamma = 2.0f * PI / 365.0f * (float)(dayOfYear - 1);

  // Equation of time in minutes
  float eqtime = 229.18f * (0.000075f + 0.001868f * cos(gamma) - 0.032077f * sin(gamma)
                 - 0.014615f * cos(2.0f * gamma) - 0.040849f * sin(2.0f * gamma));

  // Solar declination in radians
  float decl = 0.006918f - 0.399912f * cos(gamma) + 0.070257f * sin(gamma)
               - 0.006758f * cos(2.0f * gamma) + 0.000907f * sin(2.0f * gamma)
               - 0.002697f * cos(3.0f * gamma) + 0.00148f * sin(3.0f * gamma);

  float latRad = lat * PI / 180.0f;
  float zenithRad = 90.833f * PI / 180.0f; // Official sunrise/sunset zenith angle

  float cosHa = (cos(zenithRad) / (cos(latRad) * cos(decl))) - (tan(latRad) * tan(decl));
  if (cosHa < -1.0f || cosHa > 1.0f) {
    return; // Polar day / night
  }

  float haDeg = acos(cosHa) * 180.0f / PI;

  // Sunrise and sunset in minutes from UTC midnight
  float sunriseUtc = 720.0f - 4.0f * (lon + haDeg) - eqtime;
  float sunsetUtc = 720.0f - 4.0f * (lon - haDeg) - eqtime;

  // Offset in minutes
  float tzOffsetMin = (float)gmtOffset_sec / 60.0f;
  float sunriseLocal = fmod(sunriseUtc + tzOffsetMin + 1440.0f, 1440.0f);
  float sunsetLocal = fmod(sunsetUtc + tzOffsetMin + 1440.0f, 1440.0f);

  int srH = (int)(sunriseLocal / 60.0f);
  int srM = (int)fmod(sunriseLocal, 60.0f);
  const char* srAmPm = (srH >= 12) ? "PM" : "AM";
  int srH12 = srH % 12;
  if (srH12 == 0) srH12 = 12;

  int ssH = (int)(sunsetLocal / 60.0f);
  int ssM = (int)fmod(sunsetLocal, 60.0f);
  const char* ssAmPm = (ssH >= 12) ? "PM" : "AM";
  int ssH12 = ssH % 12;
  if (ssH12 == 0) ssH12 = 12;

  char buf[16];
  snprintf(buf, sizeof(buf), "%02d:%02d %s", srH12, srM, srAmPm);
  sunriseTime = String(buf);

  snprintf(buf, sizeof(buf), "%02d:%02d %s", ssH12, ssM, ssAmPm);
  sunsetTime = String(buf);

  moonriseTime = "--:--";
  moonsetTime = "--:--";

  Serial.print(F("Sunrise: ")); Serial.print(sunriseTime);
  Serial.print(F(", Sunset: ")); Serial.println(sunsetTime);
}

String formatTimestamp(time_t ts) {
  if (ts <= 0) return "--:--";
  time_t localTs = ts + gmtOffset_sec;
  struct tm *ti = gmtime(&localTs);
  if (!ti) return "--:--";
  char buf[12];
  int hour = ti->tm_hour;
  int min = ti->tm_min;
  const char* ampm = (hour >= 12) ? "PM" : "AM";
  hour = hour % 12;
  if (hour == 0) hour = 12;
  snprintf(buf, sizeof(buf), "%02d:%02d %s", hour, min, ampm);
  return String(buf);
}

void displayInfo() {
  display.clearDisplay();

  struct tm timeinfo;
  bool hasTime = getLocalTime(&timeinfo);

  if (hasTime) {
    char timeHour[3], timeMinute[3], timeAmPm[3], dateString[20];
    strftime(timeHour, sizeof(timeHour), "%I", &timeinfo);
    strftime(timeMinute, sizeof(timeMinute), "%M", &timeinfo);
    strftime(timeAmPm, sizeof(timeAmPm), "%p", &timeinfo);
    strftime(dateString, sizeof(dateString), "%a, %b %d", &timeinfo);

    String timeStr = String(timeHour) + ((timeinfo.tm_sec % 2 == 0) ? ":" : " ") + String(timeMinute) + " " + String(timeAmPm);
    display.setTextSize(2);
    drawCenteredString(timeStr, 5);

    display.setTextSize(1);
    int16_t x1, y1;
    uint16_t w, h;
    display.getTextBounds(dateString, 0, 0, &x1, &y1, &w, &h);
    int x = (SCREEN_WIDTH - w) / 2;
    int y = 25;
    display.drawRect(x - 2, y - 2, w + 4, h + 4, SSD1306_WHITE);
    display.setCursor(x, y);
    display.println(dateString);
  } else {
    display.setTextSize(2);
    drawCenteredString("--:--", 5);
    display.setTextSize(1);
    drawCenteredString("Syncing Time...", 25);
  }

  String infoText;
  const unsigned char* icon = nullptr;

switch (infoState) {
  case 0:
    infoText = location;
    icon = locationIcon;
    break;
  case 1:
    infoText = weatherCondition;
    icon = cloudIcon; // Generic cloud for condition text
    break;
  case 2:
    infoText = "Humidity: " + String(humidity) + "%";
    icon = dropletIcon;
    break;
  case 3:
    infoText = "Air Quality: " + String(airQuality);
    icon = airIcon;
    break;
  case 4:
    infoText = "Temperature: " + String(temperature, 1) + " C";
    icon = thermometerIcon;
    break;
case 5: {
  String shortDesc = forecastCondition[1];
  int spaceIndex = shortDesc.indexOf(' ');
  if (spaceIndex > 0 && spaceIndex < 12) {
    shortDesc = shortDesc.substring(0, spaceIndex);
  } else if (shortDesc.length() > 12) {
    shortDesc = shortDesc.substring(0, 12);
  }

  String line1 = "Tomorrow";
  String line2 = shortDesc + ", " + String(forecastTemp[1], 1) + " C";
  icon = cloudIcon;

  display.setTextSize(1);

  int16_t tx1, ty1, tx2, ty2;
  uint16_t tw1, th1, tw2, th2;
  display.getTextBounds(line1, 0, 0, &tx1, &ty1, &tw1, &th1);
  display.getTextBounds(line2, 0, 0, &tx2, &ty2, &tw2, &th2);

  int startX1 = (SCREEN_WIDTH - tw1) / 2;
  int startX2 = (SCREEN_WIDTH - tw2) / 2;

  if (icon != nullptr) {
    display.drawBitmap(startX1 - 10, 45, icon, 8, 8, SSD1306_WHITE);
  }

  display.setCursor(startX1, 45);
  display.println(line1);
  display.setCursor(startX2, 55);
  display.println(line2);
  display.display();
  return;
}

  case 6:
    infoText = "Humidity: " + String(forecastHumidity[1]) + "%";
    icon = dropletIcon;
    break;
  case 7: {
    String dateStr = forecastDay[1]; // API gives "YYYY-MM-DD"
    if (dateStr.length() >= 10) {
      // Parse the date string from the API
      int year = dateStr.substring(0, 4).toInt();
      int month = dateStr.substring(5, 7).toInt();
      int day = dateStr.substring(8, 10).toInt();

      // Create a time structure to hold the parsed date
      struct tm forecast_tm = {0};
      forecast_tm.tm_year = year - 1900; // Years since 1900
      forecast_tm.tm_mon = month - 1;    // Months since January (0-11)
      forecast_tm.tm_mday = day;
      forecast_tm.tm_isdst = -1;         // Let mktime figure out DST

      // This calculates the day of the week (e.g., Wednesday) for the date
      mktime(&forecast_tm);

      // Buffers to hold the month and day of the week abbreviations
      char monthAbbr[5];
      char dayAbbr[5];

      // Format the date parts into the buffers
      strftime(monthAbbr, sizeof(monthAbbr), "%b", &forecast_tm); // e.g., "Oct"
      strftime(dayAbbr, sizeof(dayAbbr), "%a", &forecast_tm);   // e.g., "Wed"
      
      // Convert the abbreviations to strings so we can make them lowercase
      String monthStr = String(monthAbbr);
      String dayWStr = String(dayAbbr);
      monthStr.toLowerCase(); // -> "oct"
      dayWStr.toLowerCase();  // -> "wed"
      
      // Assemble the final string in the desired format
      infoText = "Tomorrow " + String(day) + " " + monthStr + " " + dayWStr;

    } else {
      // Fallback in case the API format is unexpected
      infoText = "Date: " + forecastDay[1];
    }
    icon = calendarIcon;
    break;
  }
  case 8:
    infoText = "Have a bright day!";
    icon = sunIcon;
    break;

  case 9: {
    String shortCondition;
    const unsigned char* selectedIcon = nullptr;
    
    int currentHour = hasTime ? timeinfo.tm_hour : 12; 
    bool isNight = (currentHour >= 19 || currentHour < 6);

    if (weatherCondition.indexOf("Rain") != -1 || weatherCondition.indexOf("Shower") != -1 || weatherCondition.indexOf("Drizzle") != -1 || weatherCondition.indexOf("rain") != -1) {
      selectedIcon = rainIcon;
      shortCondition = "Rainy";
    } else if (weatherCondition.indexOf("Sun") != -1 || weatherCondition.indexOf("Clear") != -1 || weatherCondition.indexOf("sun") != -1 || weatherCondition.indexOf("clear") != -1) {
      if (isNight) {
        selectedIcon = moonIcon; 
        shortCondition = "Clear Night";
      } else {
        selectedIcon = sunIcon;
        shortCondition = "Sunny";
      }
    } else if (weatherCondition.indexOf("Cloud") != -1 || weatherCondition.indexOf("Overcast") != -1 || weatherCondition.indexOf("cloud") != -1) {
      if (weatherCondition.indexOf("scattered") != -1 || weatherCondition.indexOf("broken") != -1 || weatherCondition.indexOf("Partly") != -1) {
        selectedIcon = partlyCloudyIcon;
        shortCondition = (isNight ? "P. Cloudy Night" : "P. Cloudy"); 
      } else {
        selectedIcon = cloudIcon;
        shortCondition = "Cloudy";
      }
    } else {
      selectedIcon = cloudIcon;
      if (weatherCondition.length() > 12){
        shortCondition = weatherCondition.substring(0,12);
      } else{
      shortCondition = weatherCondition;
      }
    }

    display.setTextSize(1);
    drawCenteredString("Current Weather", 40); 

    int16_t tx, ty;
    uint16_t tw, th;
    display.getTextBounds(shortCondition, 0, 0, &tx, &ty, &tw, &th);

    int totalWidth = 8 + 4 + tw;
    int startX = (SCREEN_WIDTH - totalWidth) / 2;

    if (selectedIcon != nullptr) {
        display.drawBitmap(startX, 52, selectedIcon, 8, 8, SSD1306_WHITE);
    }

    display.setCursor(startX + 8 + 4, 54); 
    display.println(shortCondition);

    display.display();
    return; 
  }

  case 10:
    infoText = "Wind: " + String(windSpeed, 1) + " kmph";
    icon = windSpeedIcon;
    break;

  case 11:
    infoText = "Wind Dir: " + (windDirection.length() > 0 ? windDirection : String(windDirDegrees) + " deg");
    icon = (windDirection.length() > 0) ? getWindArrowIcon(windDirection) : getWindArrowIcon(windDirDegrees);
    break;

  case 12:
    infoText = "Sunrise: " + sunriseTime;
    icon = sunriseIcon;
    break;

  case 13:
    infoText = "Sunset: " + sunsetTime;
    icon = sunsetIcon;
    break;

  case 14:
    infoText = "Moonrise: " + moonriseTime;
    icon = moonriseIcon;
    break;

  case 15:
    infoText = "Moonset: " + moonsetTime;
    icon = moonsetIcon;
    break;
}


  int16_t tx, ty;
  uint16_t tw, th;
  display.getTextBounds(infoText, 0, 0, &tx, &ty, &tw, &th);
  int totalWidth = 8 + 2 + tw;
  int startX = (SCREEN_WIDTH - totalWidth) / 2;

  if (icon != nullptr) {
    display.drawBitmap(startX, 45, icon, 8, 8, SSD1306_WHITE);
  }
  display.setCursor(startX + 10, 47);
  display.println(infoText);

  display.display();
}

void drawCenteredString(const String &text, int y) {
  int16_t x1, y1;
  uint16_t w, h;
  display.getTextBounds(text, 0, 0, &x1, &y1, &w, &h);
  int x = (SCREEN_WIDTH - w) / 2;
  display.setCursor(x, y);
  display.println(text);
}

