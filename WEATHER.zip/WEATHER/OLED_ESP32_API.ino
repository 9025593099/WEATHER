// ESP32 Board link "https://raw.githubusercontent.com/espressif/arduino-esp32/gh-pages/package_esp32_index.json"
#include <WiFi.h>
#include <HTTPClient.h>
#include <ArduinoJson.h>
#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>
#include "time.h"
#include "Imojies.h" // Ensure this file defines moonIcon, sunIcon, cloudIcon, etc.

// --- Wi-Fi & API ---
const char* ssid = "KIRUBAI ILLAM";
const char* password = "Sjebajas";

// Latitude and Longitude (Mukuperi: lat=8.5705091, lon=77.9878221)
String latitude = "8.5705091";
String longitude = "77.9878221";
String Authentication_Key = "866dd83d9e0646958f0f6538665b8263";

// Weatherbit lat/lon endpoints (http avoids ESP32 TLS handshake overhead)
String currentWeatherURL = "http://api.weatherbit.io/v2.0/current?lat=" + latitude + "&lon=" + longitude + "&key=" + Authentication_Key;
String forecastURL = "http://api.weatherbit.io/v2.0/forecast/daily?lat=" + latitude + "&lon=" + longitude + "&days=3&key=" + Authentication_Key;

// --- Time ---
const char* ntpServer = "pool.ntp.org";   
const long gmtOffset_sec = 19800;
const int daylightOffset_sec = 0;

// --- Display ---
#define SCREEN_WIDTH 128
#define SCREEN_HEIGHT 64
#define OLED_RESET -1
#define SCREEN_ADDRESS 0x3C
Adafruit_SSD1306 display(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire, OLED_RESET);

// --- Weather Data ---
String weatherCondition = "";
int humidity = 0;
int airQuality = 0;
float temperature = 0.0;
String location = "Mukuperi";

// --- Forecast Data ---
String forecastDay[3];
String forecastCondition[3];
float forecastTemp[3];
int forecastHumidity[3];

// --- UI State ---
int infoState = 0;
unsigned long lastInfoChange = 0;
const int infoInterval = 4000;
unsigned long lastWeatherUpdate = 0;
const int weatherUpdateInterval = 15 * 60 * 1000;

// --- Connection State ---
bool wasConnected = false;

// --- Functions (Prototypes) ---
void drawCenteredString(const String &text, int y);
void connectWiFi();
void handleWiFiDisconnection();
void displayInfo();
void initTime();
void getWeatherData();
void getForecastData();

// --- Setup ---
void setup() {
  Serial.begin(115200);
  Wire.begin(21, 22); // Explicitly define I2C pins for ESP32

  // Initialize SSD1306 OLED
  if (!display.begin(SSD1306_SWITCHCAPVCC, SCREEN_ADDRESS)) {
    Serial.println(F("SSD1306 allocation failed"));
    for (;;);
  }

  display.clearDisplay();
  display.setTextSize(1);
  display.setTextColor(SSD1306_WHITE);

  connectWiFi();

  if (WiFi.status() == WL_CONNECTED) {
    wasConnected = true;
  }

  initTime();
  getWeatherData();
  getForecastData();

  // ✅ Prevent skipping case 0
  lastInfoChange = millis();

  // ✅ Show case 0 immediately at startup
  displayInfo();
}

// --- Loop ---
void loop() {
  if (WiFi.status() == WL_CONNECTED) {
    if (!wasConnected) {
      wasConnected = true;
      Serial.println("Reconnected to WiFi.");
      initTime();
      getWeatherData();
      getForecastData();
      lastWeatherUpdate = millis();

      display.clearDisplay();
      drawCenteredString("Reconnected!", SCREEN_HEIGHT / 2 - 5);
      display.display();
      delay(1500);
    }

    unsigned long currentTime = millis();

    if (currentTime - lastWeatherUpdate > weatherUpdateInterval) {
      getWeatherData();
      getForecastData();
      lastWeatherUpdate = currentTime;
    }

    if (currentTime - lastInfoChange > infoInterval) {
      infoState = (infoState + 1) % 10;
      lastInfoChange = currentTime;
    }

    displayInfo();
  } else {
    if (wasConnected) {
      Serial.println("WiFi connection lost. Attempting to reconnect...");
      wasConnected = false;
    }
    handleWiFiDisconnection(); 
  }
}

// --- Functions ---
void handleWiFiDisconnection() {
  // Static variables to persist state across function calls
  static int x_pos = -20; // Animation position
  static unsigned long lastReconnectAttempt = 0;
  const int reconnectInterval = 10000; // Try to reconnect every 10 seconds

  unsigned long currentTime = millis();

  // Periodically attempt to reconnect in a non-blocking way
  if (currentTime - lastReconnectAttempt > reconnectInterval) {
    Serial.println("Attempting WiFi reconnection...");
    WiFi.begin(ssid, password); // This is non-blocking
    lastReconnectAttempt = currentTime;
  }

  // --- Draw the Disconnected UI ---
  display.clearDisplay();

  // 1. Draw Time and Date (still works from internal clock)
  struct tm timeinfo;
  if (!getLocalTime(&timeinfo)) {
    display.setTextSize(2);
    drawCenteredString("??:?? ??", 5);
    display.setTextSize(1);
    drawCenteredString("No Time Sync", 25);
  } else {
    char timeHour[3], timeMinute[3], timeAmPm[3], dateString[20];
    strftime(timeHour, sizeof(timeHour), "%I", &timeinfo);
    strftime(timeMinute, sizeof(timeMinute), "%M", &timeinfo);
    strftime(timeAmPm, sizeof(timeAmPm), "%p", &timeinfo);
    strftime(dateString, sizeof(dateString), "%a, %b %d", &timeinfo);

    String timeStr = String(timeHour) + ((timeinfo.tm_sec % 2 == 0) ? ":" : " ") + String(timeMinute) + " " + String(timeAmPm);
    display.setTextSize(2);
    drawCenteredString(timeStr, 5);

    display.setTextSize(1);
    int16_t x1, y1;
    uint16_t w, h;
    display.getTextBounds(dateString, 0, 0, &x1, &y1, &w, &h);
    int x = (SCREEN_WIDTH - w) / 2;
    int y = 25;
    display.drawRect(x - 2, y - 2, w + 4, h + 4, SSD1306_WHITE);
    display.setCursor(x, y);
    display.println(dateString);
  }

  // 2. Draw Disconnected Message
  display.setTextSize(1);
  drawCenteredString("WiFi Disconnected", 45);

  // 3. Draw Reconnecting Animation (marquee line at the bottom)
  const int LINE_WIDTH = 30;
  const int LINE_HEIGHT = 2;
  const int Y_POS = SCREEN_HEIGHT - LINE_HEIGHT - 2; // Position at the very bottom
  const int ANIMATION_SPEED = 4;

  display.fillRect(0, Y_POS, SCREEN_WIDTH, LINE_HEIGHT, SSD1306_BLACK); // Clear animation area

  int draw_start_x = max(0, x_pos);
  int draw_width = LINE_WIDTH;
  if (x_pos < 0) { draw_width = LINE_WIDTH + x_pos; }
  if (x_pos + LINE_WIDTH > SCREEN_WIDTH) { draw_width = SCREEN_WIDTH - x_pos; }
  if (draw_width > 0) { display.drawFastHLine(draw_start_x, Y_POS, draw_width, SSD1306_WHITE); }
  
  x_pos += ANIMATION_SPEED;
  if (x_pos > SCREEN_WIDTH) { x_pos = -LINE_WIDTH; } // Reset animation

  display.display();
  delay(50); // Delay for animation smoothness
}


void connectWiFi() {
  Serial.print("Connecting to ");
  Serial.println(ssid);
  
  display.clearDisplay();
  display.setTextSize(1);
  drawCenteredString("Connecting", SCREEN_HEIGHT / 2 - 10);
  
  WiFi.begin(ssid, password);
  
  const int LINE_WIDTH = 20;
  const int LINE_HEIGHT = 2;
  const int Y_POS = SCREEN_HEIGHT / 2 + 5;
  const int ANIMATION_SPEED = 3; 
  int x_pos = 0;
  
  while (WiFi.status() != WL_CONNECTED) {
    display.fillRect(0, Y_POS, SCREEN_WIDTH, LINE_HEIGHT, SSD1306_BLACK); 

    int draw_start_x = max(0, x_pos); 
    int draw_width = LINE_WIDTH; 
    
    if (x_pos < 0) {
        draw_width = LINE_WIDTH + x_pos;
    }
    if (x_pos + LINE_WIDTH > SCREEN_WIDTH) {
        draw_width = SCREEN_WIDTH - x_pos;
    }

    if (draw_width > 0) {
        display.drawFastHLine(draw_start_x, Y_POS, draw_width, SSD1306_WHITE);
    }
    
    x_pos += ANIMATION_SPEED;
    
    if (x_pos > SCREEN_WIDTH) {
      x_pos = -LINE_WIDTH; 
    }
    
    display.display();
    Serial.print(".");
    delay(50); 
  }
  
  display.clearDisplay();
  display.setTextSize(1);
  drawCenteredString("WiFi connected!", SCREEN_HEIGHT / 2 - 5);
  display.display();
  delay(1000); 

  Serial.println("\nWiFi connected.");
}

void initTime() {
  configTime(gmtOffset_sec, daylightOffset_sec, ntpServer);
  Serial.println("Time synchronized.");
}

void getWeatherData() {
  if (WiFi.status() == WL_CONNECTED) {
    HTTPClient http;
    http.begin(currentWeatherURL.c_str());
    int httpResponseCode = http.GET();

    Serial.print("Weather HTTP Code: ");
    Serial.println(httpResponseCode);

    if (httpResponseCode == HTTP_CODE_OK) {
      String payload = http.getString();
      DynamicJsonDocument doc(1024);
      DeserializationError error = deserializeJson(doc, payload);

      if (error) {
        Serial.println("JSON error: " + String(error.c_str()));
        http.end();
        return;
      }

      weatherCondition = doc["data"][0]["weather"]["description"].as<String>();
      humidity = doc["data"][0]["rh"].as<int>();
      airQuality = doc["data"][0]["aqi"].as<int>();
      temperature = doc["data"][0]["temp"].as<float>();
      location = "Mukuperi";

      Serial.print("Weather: ");
      Serial.print(weatherCondition);
      Serial.print(", Temp: ");
      Serial.println(temperature);
    } else {
      Serial.print("Failed to fetch weather. Code: ");
      Serial.println(httpResponseCode);
    }
    http.end();
  }
}

void getForecastData() {
  if (WiFi.status() == WL_CONNECTED) {
    HTTPClient http;
    http.begin(forecastURL.c_str());
    int httpResponseCode = http.GET();

    Serial.print("Forecast HTTP Code: ");
    Serial.println(httpResponseCode);

    if (httpResponseCode == HTTP_CODE_OK) {
      String payload = http.getString();
      DynamicJsonDocument doc(2048);
      DeserializationError error = deserializeJson(doc, payload);

      if (error) {
        Serial.println("Forecast JSON error: " + String(error.c_str()));
        http.end();
        return;
      }

      for (int i = 0; i < 3; i++) {
        forecastDay[i] = doc["data"][i]["datetime"].as<String>();
        forecastCondition[i] = doc["data"][i]["weather"]["description"].as<String>();
        forecastTemp[i] = doc["data"][i]["temp"].as<float>();
        forecastHumidity[i] = doc["data"][i]["rh"].as<int>();
      }
    } else {
      Serial.print("Failed to fetch forecast. Code: ");
      Serial.println(httpResponseCode);
    }
    http.end();
  }
}

void displayInfo() {
  display.clearDisplay();

  struct tm timeinfo;
  bool hasTime = getLocalTime(&timeinfo);

  if (hasTime) {
    char timeHour[3], timeMinute[3], timeAmPm[3], dateString[20];
    strftime(timeHour, sizeof(timeHour), "%I", &timeinfo);
    strftime(timeMinute, sizeof(timeMinute), "%M", &timeinfo);
    strftime(timeAmPm, sizeof(timeAmPm), "%p", &timeinfo);
    strftime(dateString, sizeof(dateString), "%a, %b %d", &timeinfo);

    String timeStr = String(timeHour) + ((timeinfo.tm_sec % 2 == 0) ? ":" : " ") + String(timeMinute) + " " + String(timeAmPm);
    display.setTextSize(2);
    drawCenteredString(timeStr, 5);

    display.setTextSize(1);
    int16_t x1, y1;
    uint16_t w, h;
    display.getTextBounds(dateString, 0, 0, &x1, &y1, &w, &h);
    int x = (SCREEN_WIDTH - w) / 2;
    int y = 25;
    display.drawRect(x - 2, y - 2, w + 4, h + 4, SSD1306_WHITE);
    display.setCursor(x, y);
    display.println(dateString);
  } else {
    display.setTextSize(2);
    drawCenteredString("--:--", 5);
    display.setTextSize(1);
    drawCenteredString("Syncing Time...", 25);
  }

  String infoText;
  const unsigned char* icon = nullptr;

switch (infoState) {
  case 0:
    infoText = location;
    icon = locationIcon;
    break;
  case 1:
    infoText = weatherCondition;
    icon = cloudIcon; // Generic cloud for condition text
    break;
  case 2:
    infoText = "Humidity: " + String(humidity) + "%";
    icon = dropletIcon;
    break;
  case 3:
    infoText = "Air Quality: " + String(airQuality);
    icon = airIcon;
    break;
  case 4:
    infoText = "Temperature: " + String(temperature, 1) + " C";
    icon = thermometerIcon;
    break;
case 5: {
  String shortDesc = forecastCondition[1];
  int spaceIndex = shortDesc.indexOf(' ');
  if (spaceIndex > 0 && spaceIndex < 12) {
    shortDesc = shortDesc.substring(0, spaceIndex);
  } else if (shortDesc.length() > 12) {
    shortDesc = shortDesc.substring(0, 12);
  }

  String line1 = "Tomorrow";
  String line2 = shortDesc + ", " + String(forecastTemp[1], 1) + " C";
  icon = cloudIcon;

  display.setTextSize(1);

  int16_t tx1, ty1, tx2, ty2;
  uint16_t tw1, th1, tw2, th2;
  display.getTextBounds(line1, 0, 0, &tx1, &ty1, &tw1, &th1);
  display.getTextBounds(line2, 0, 0, &tx2, &ty2, &tw2, &th2);

  int startX1 = (SCREEN_WIDTH - tw1) / 2;
  int startX2 = (SCREEN_WIDTH - tw2) / 2;

  if (icon != nullptr) {
    display.drawBitmap(startX1 - 10, 45, icon, 8, 8, SSD1306_WHITE);
  }

  display.setCursor(startX1, 45);
  display.println(line1);
  display.setCursor(startX2, 55);
  display.println(line2);
  display.display();
  return;
}

  case 6:
    infoText = "Humidity: " + String(forecastHumidity[1]) + "%";
    icon = dropletIcon;
    break;
  case 7: {
    String dateStr = forecastDay[1]; // API gives "YYYY-MM-DD"
    if (dateStr.length() >= 10) {
      // Parse the date string from the API
      int year = dateStr.substring(0, 4).toInt();
      int month = dateStr.substring(5, 7).toInt();
      int day = dateStr.substring(8, 10).toInt();

      // Create a time structure to hold the parsed date
      struct tm forecast_tm = {0};
      forecast_tm.tm_year = year - 1900; // Years since 1900
      forecast_tm.tm_mon = month - 1;    // Months since January (0-11)
      forecast_tm.tm_mday = day;
      forecast_tm.tm_isdst = -1;         // Let mktime figure out DST

      // This calculates the day of the week (e.g., Wednesday) for the date
      mktime(&forecast_tm);

      // Buffers to hold the month and day of the week abbreviations
      char monthAbbr[5];
      char dayAbbr[5];

      // Format the date parts into the buffers
      strftime(monthAbbr, sizeof(monthAbbr), "%b", &forecast_tm); // e.g., "Oct"
      strftime(dayAbbr, sizeof(dayAbbr), "%a", &forecast_tm);   // e.g., "Wed"
      
      // Convert the abbreviations to strings so we can make them lowercase
      String monthStr = String(monthAbbr);
      String dayWStr = String(dayAbbr);
      monthStr.toLowerCase(); // -> "oct"
      dayWStr.toLowerCase();  // -> "wed"
      
      // Assemble the final string in the desired format
      infoText = "Tomorrow " + String(day) + " " + monthStr + " " + dayWStr;

    } else {
      // Fallback in case the API format is unexpected
      infoText = "Date: " + forecastDay[1];
    }
    icon = calendarIcon;
    break;
  }
  case 8:
    infoText = "Have a bright day!";
    icon = sunIcon;
    break;

  case 9: {
    String shortCondition;
    const unsigned char* selectedIcon = nullptr;
    
    int currentHour = hasTime ? timeinfo.tm_hour : 12; 
    bool isNight = (currentHour >= 19 || currentHour < 6);

    if (weatherCondition.indexOf("Rain") != -1 || weatherCondition.indexOf("Shower") != -1 || weatherCondition.indexOf("Drizzle") != -1 || weatherCondition.indexOf("rain") != -1) {
      selectedIcon = dropletIcon;
      shortCondition = "Rainy";
    } else if (weatherCondition.indexOf("Sun") != -1 || weatherCondition.indexOf("Clear") != -1 || weatherCondition.indexOf("sun") != -1 || weatherCondition.indexOf("clear") != -1) {
      if (isNight) {
        selectedIcon = moonIcon; 
        shortCondition = "Clear Night";
      } else {
        selectedIcon = sunIcon;
        shortCondition = "Sunny";
      }
    } else if (weatherCondition.indexOf("Cloud") != -1 || weatherCondition.indexOf("Overcast") != -1 || weatherCondition.indexOf("cloud") != -1) {
      if (weatherCondition.indexOf("scattered") != -1 || weatherCondition.indexOf("broken") != -1 || weatherCondition.indexOf("Partly") != -1) {
        selectedIcon = partlyCloudyIcon;
        shortCondition = (isNight ? "P. Cloudy Night" : "P. Cloudy"); 
      } else {
        selectedIcon = cloudIcon;
        shortCondition = "Cloudy";
      }
    } else {
      selectedIcon = cloudIcon;
      if (weatherCondition.length() > 12){
        shortCondition = weatherCondition.substring(0,12);
      } else{
      shortCondition = weatherCondition;
      }
    }

    display.setTextSize(1);
    drawCenteredString("Current Weather", 40); 

    int16_t tx, ty;
    uint16_t tw, th;
    display.getTextBounds(shortCondition, 0, 0, &tx, &ty, &tw, &th);

    int totalWidth = 8 + 4 + tw;
    int startX = (SCREEN_WIDTH - totalWidth) / 2;

    if (selectedIcon != nullptr) {
        display.drawBitmap(startX, 52, selectedIcon, 8, 8, SSD1306_WHITE);
    }

    display.setCursor(startX + 8 + 4, 54); 
    display.println(shortCondition);

    display.display();
    return; 
  }
}


  int16_t tx, ty;
  uint16_t tw, th;
  display.getTextBounds(infoText, 0, 0, &tx, &ty, &tw, &th);
  int totalWidth = 8 + 2 + tw;
  int startX = (SCREEN_WIDTH - totalWidth) / 2;

  if (icon != nullptr) {
    display.drawBitmap(startX, 45, icon, 8, 8, SSD1306_WHITE);
  }
  display.setCursor(startX + 10, 47);
  display.println(infoText);

  display.display();
}

void drawCenteredString(const String &text, int y) {
  int16_t x1, y1;
  uint16_t w, h;
  display.getTextBounds(text, 0, 0, &x1, &y1, &w, &h);
  int x = (SCREEN_WIDTH - w) / 2;
  display.setCursor(x, y);
  display.println(text);
}
